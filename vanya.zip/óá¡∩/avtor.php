<?php
$login=filter_var(trim($_POST['login']),
 FILTER_SANITIZE_STRING);
$password=filter_var(trim($_POST['password']),
  FILTER_SANITIZE_STRING);
$repassword=filter_var(trim($_POST['repassword']),
  FILTER_SANITIZE_STRING);

$password = md5($password."ygk12345");
$repassword = md5($repassword."ygk12345");

$mysql = new mysqli('localhost', 'root', '', 'exam');

$result = $mysql->query("SELECT * FROM `reguser` WHERE `login` = '$login'");
$user = $result->fetch_assoc();
if(empty($user) or count($user) == 0){
  echo "Такой пользователь не существует!";
  exit();
}

setcookie('user', $user['login'], time() + 3600 * 24, "/");


$mysql->close();

header('Location: cab.php')
?>
