<html>
<head>
<meta charset="utf-8">
<link href="styles.css" media="screen" rel="stylesheet" type="text/css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<div class="container">
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <button
      class="navbar-toggler"
      type="button"
      data-mdb-toggle="collapse"
      data-mdb-target="#navbarTogglerDemo01"
      aria-controls="navbarTogglerDemo01"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
      <a class="navbar-brand" href="#" style="margin-left: 20px">Область</a>
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

      <form class="d-flex input-group w-auto" style="margin-left:1600px; padding-top: 15px">
        <a class="btn btn-outline-primary" type="submit" href="reg.php" data-mdb-ripple-color="dark">Личный кабинет</a>
      </form>
    </div>
  </div>

</nav>
</div>
</head>
<body style="background-color: white">
<div style="background-color: black; margin-top: 1200px;">
asdad
</div>
</body>
</html>
